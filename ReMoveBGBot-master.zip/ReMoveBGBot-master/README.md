# Remove_BGBot

### LICENSE
- GPLv3

- For FeedBack and Suggestions, please feel free to say in [@SpEcHlDe](https://telegram.dog/ShrimadhaVahdamirhS)
